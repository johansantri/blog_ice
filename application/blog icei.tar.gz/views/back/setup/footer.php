
    <script src="<?php echo base_url()?>assets/js/main.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>assets/js/plugins/select2.min.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url()?>assets/js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/plugins/chart.js"></script>
 
    <script type="text/javascript">
    	 $('#demoSelect').select2();
    	  $('#kepSelect').select2();
           $('#kepSelectA').select2();
                $('#id_pelanggan').select2();
    </script>
   
   
  </body>
</html>